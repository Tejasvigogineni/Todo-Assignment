# To-do-list
using html,css,sql,php
we will create a Simple To-Do List App using PHP. PHP is a server-side scripting language designed primarily for web development. Using PHP, you can let your user directly interact with the script and easily to learned its syntax. It is mostly used by newly coders for its user-friendly environment.

Getting started:
First you have to download & install XAMPP or any local server that run PHP scripts. Here's the link for XAMPP server https://www.apachefriends.org/index.html.

Creating Database
Open your database web server then create a database name in it db_task. After that, click Import then locate the database file inside the folder of the application then click ok.
